/*E3.8*/
#include<stdio.h>
int main(void)
{
	int a=98;
	char ch='c';
	printf("%c,%d\n",a,ch);
	return 0;
}